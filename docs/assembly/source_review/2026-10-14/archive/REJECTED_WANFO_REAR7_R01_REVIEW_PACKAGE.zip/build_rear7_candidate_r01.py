from pathlib import Path
import copy,json,gzip,itertools,hashlib
import numpy as np,trimesh,manifold3d as mf
from shapely.geometry import Polygon

R=Path('/workspace/scratch/c8225efbedd1');D=R/'rear7_candidate_r01';D.mkdir(exist_ok=True)
S=R/'upper6_front_tenon_c01/INPUT_GEOMETRY.json';data=json.loads(S.read_text());original=copy.deepcopy(data);old={o['id']:o for o in original['objects']};objects={o['id']:o for o in data['objects']}
PF='trial:EAST_FRONT_';PR='trial:EAST_REAR_';upper='trial:EAST_UPPER6_FULL_BEAM_CANDIDATE'
names=['COLUMN_CANDIDATE','COLUMN_LUDOU','HUA1_LOCAL','INTERACTIVE_DOU_LOCAL','HUA2_LOCAL','TOU_ANG_LOCAL','ER_ANG_LOCAL']
evidence={
 'COLUMN_CANDIDATE':{'reference':'existing approved column Master diameter approximately460; height3534.3 replaceable D-023 design','rear_individual_dimensions_verified':False},
 'COLUMN_LUDOU':{'reference':'A1 PDF62 table2-26 family means; PDF292 rear node contour','rear_individual_dimensions_verified':False},
 'HUA1_LOCAL':{'reference':'A1 PDF58-61 huagong family and approved T040 definition','rear_individual_dimensions_verified':False},
 'INTERACTIVE_DOU_LOCAL':{'reference':'A1 PDF65 table2-29 family means; PDF73/292 interlocking roles','rear_individual_dimensions_verified':False},
 'HUA2_LOCAL':{'reference':'A1 PDF58-61 huagong family; PDF72-73 crossing relations','rear_individual_dimensions_verified':False},
 'TOU_ANG_LOCAL':{'reference':'A1 PDF52-53 head-ang section family; PDF72/79 ideal47:21 slope; PDF336 north-east head L/R instance variability','rear_individual_dimensions_verified':False},
 'ER_ANG_LOCAL':{'reference':'A1 PDF53-54 second-ang section family; PDF81 upper6 rests on second-ang; PDF336 north-east head L/R variability','rear_individual_dimensions_verified':False}}
sourcegate={'status':'PASS_FOR_BOUNDED_EXPLORATORY_CANDIDATE_NOT_REAR_HISTORICAL_FORM','source_A1_sha256':'94c2fedef64fd81ce225e04da4757d33ada34b9413b01baaf023fa72baed3472','reviewed_A1_pages':[49,50,51,52,53,54,55,56,57,58,59,60,61,62,65,72,73,78,292,336,342],'seven_member_evidence':evidence,'facts':'same-building rear node supports member roles; family dimensions exist; approved column Master uses explicit height completion','hypotheses':['reflect local front mesh seeds across Y=0','rear column centre Y=-5355 from existing beam end','same ideal local layer heights and 21/47 slope','same local mesh seed contours, cuts and slots; no source-fitted rear hidden joinery'],'unknowns':['unique rear physical instance and L/R scan side binding','rear individual exact profiles and dimensions','rear slot depths and complete ang tails','foundation support and strength'],'production_scope':'seven pending local candidates only; not complete rear bracket','authorized_by_user':'按正确顺序进行 2026-10-13T19:42:59+08:00'}
(D/'SOURCE_GATE.json').write_text(json.dumps(sourcegate,ensure_ascii=False,indent=2))
for n in names:
 seed=old[PF+n];a=copy.deepcopy(seed);a['id']=PR+n;assert a['id'] not in objects
 v=np.array(seed['vertices']);v[:,1]*=-1;origin=np.array(seed['origin']);origin[1]*=-1
 a['vertices']=v.tolist();a['faces']=[[f[0],f[2],f[1]] for f in seed['faces']];a['origin']=origin.tolist();a['local_vertices']=(v-origin).tolist();a['display_group']='PENDING_CANDIDATES';a['effective_status']='PENDING_REAR7_R01_FORM_APPROVAL';a['approval_record']='2026-10-13T19:42:59+08:00 AUTHORIZE_SOURCE_THEN_CANDIDATE_AND_TEST_ONLY'
 a['properties']={'local_revision':'REAR7_R01','geometry_seed_id':PF+n,'geometry_seed_status':seed['effective_status'],'seed_approval_not_transferred':True,'source_reference':evidence[n]['reference'],'rear_individual_shape_verified':False,'reflection':'Y -> -Y; WORKING_HYPOTHESIS','absolute_layer_heights':'front local layer reconstruction reused; WORKING_HYPOTHESIS','joinery':'reconstructed local interfaces inherited as design seed; NOT historical rear joinery','scope':'partial longitudinal chain; not full historical member/bracket','historical_claim':False};objects[a['id']]=a;data['objects'].append(a)
def mesh(a):return trimesh.Trimesh(a['vertices'],a['faces'],process=False)
def man(m,c):return mf.Manifold(mf.Mesh64(vert_properties=np.array(m.vertices-c,dtype='f8',order='C'),tri_verts=np.array(m.faces,dtype='u8',order='C')))
def overlap(x,y):
 lo=np.maximum(x.bounds[0],y.bounds[0]);hi=np.minimum(x.bounds[1],y.bounds[1])
 if not np.all(hi>lo):return 0.
 c=(hi+lo)/2;return abs(float((man(x,c)^man(y,c)).volume()))
def surface(a,b,down=False):
 total=0.
 for i,t in enumerate(a.triangles):
  n=a.face_normals[i]
  if down and n[2]>=-1e-8:continue
  u=t[1]-t[0];u/=np.linalg.norm(u);v=np.cross(n,u);pa=Polygon(np.c_[(t-t[0])@u,(t-t[0])@v])
  for j,q in enumerate(b.triangles):
   if np.dot(n,b.face_normals[j])>-1+1e-7 or np.max(abs((q-t[0])@n))>.001:continue
   pb=Polygon(np.c_[(q-t[0])@u,(q-t[0])@v]);total+=pa.intersection(pb).area*(-n[2] if down else 1)
 return float(total)
newcontacts=[{'a':PR+a,'b':PR+b,'downward_required':True} for a,b in [('COLUMN_LUDOU','COLUMN_CANDIDATE'),('HUA1_LOCAL','COLUMN_LUDOU'),('INTERACTIVE_DOU_LOCAL','HUA1_LOCAL'),('HUA2_LOCAL','INTERACTIVE_DOU_LOCAL'),('TOU_ANG_LOCAL','HUA2_LOCAL'),('ER_ANG_LOCAL','TOU_ANG_LOCAL')]]+[{'a':upper,'b':PR+'ER_ANG_LOCAL','downward_required':True}]
ms={k:mesh(a) for k,a in objects.items()};newids=[PR+n for n in names];minimalkeys=newids+[upper];contacts=[]
for c in newcontacts:
 area=surface(ms[c['a']],ms[c['b']]);dp=surface(ms[c['a']],ms[c['b']],True);contacts.append(dict(c,area_mm2=area,downward_mm2=dp,pass_check=bool(area>100 and dp>100)))
minimum={'status':'PASS' if all(c['pass_check'] for c in contacts) else 'FAIL_STOP','scope':'7 new rear members + existing upper6; longitudinal only','new_contacts':contacts,'pair_count':28,'max_overlap_mm3':max(overlap(ms[a],ms[b]) for a,b in itertools.combinations(minimalkeys,2)),'closed_positive_single_connected':all(ms[k].is_volume and len(ms[k].split(only_watertight=False))==1 for k in minimalkeys),'existing82_source_exact':all(objects[k]==old[k] for k in old),'foundation_and_transverse_constraints':'NOT_TESTED'}
minimum['pass']=bool(minimum['status']=='PASS' and minimum['max_overlap_mm3']<=1 and minimum['closed_positive_single_connected'] and minimum['existing82_source_exact']);(D/'SEVEN_MEMBER_CHAIN_MINIMUM_PROOF.json').write_text(json.dumps(minimum,ensure_ascii=False,indent=2));print('MINIMUM',minimum['pass'],minimum['max_overlap_mm3'],flush=True);assert minimum['pass'],'STOP_MINIMUM_FAIL'
data['contacts'].extend(newcontacts);oldms={k:mesh(a) for k,a in old.items()};maximum=0.;fail=[];paircount=0
for a,b in itertools.combinations(ms,2):
 volume=overlap(ms[a],ms[b]);maximum=max(maximum,volume);paircount+=1
 if volume>1:fail.append({'a':a,'b':b,'overlap_mm3':volume})
allcontacts=[]
for c in data['contacts']:
 a,b=c['a'],c['b'];area=surface(ms[a],ms[b]);ref=surface(oldms[a],oldms[b]) if a in oldms and b in oldms else None;dp=surface(ms[a],ms[b],True) if c['downward_required'] else None
 allcontacts.append(dict(c,area_mm2=area,prior_area_mm2=ref,downward_mm2=dp,pass_check=bool(area>100 and (ref is None or area>=ref*.99) and (dp is None or dp>100))))
extra=surface(ms[PF+'NIDAO_GUAZI'],ms[PF+'COLUMN_LUDOU'],True)
r={'entity_count':89,'new_pending_ids':newids,'existing82_source_exact':all(objects[k]==old[k] for k in old),'pair_count':paircount,'max_overlap_mm3':maximum,'threshold_mm3':1,'failed_pairs':fail,'contacts':allcontacts,'retained_original_contact_count':43,'new_longitudinal_contact_count':7,'C02_extra_guazi_ludou_downward_contact_mm2':extra,'closed_positive_single_connected':all(m.is_volume and len(m.split(only_watertight=False))==1 for m in ms.values()),'form_approval':'PENDING_ALL7','cloud_blend_roundtrip':'NOT_RUN','rear_historical_shape':'NOT_PROVEN','strength_and_transverse_lateral_constraints':'NOT_TESTED'}
r['pass']=bool(r['existing82_source_exact'] and not fail and all(c['pass_check'] for c in allcontacts) and r['closed_positive_single_connected'] and extra>100);(D/'REAR7_R01_VALIDATION.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print('FULL89',r['pass'],maximum,flush=True);assert r['pass'],'STOP_FULL_FAIL'
data['candidate_pending_ids']=newids;data['candidate_changes']=[{'id':k,'new_entity':True,'geometry_hypothesis':'reflected local seed; rear individual form unverified'} for k in newids];data['comparison_baseline']='upper6 front C01 approved local input '+hashlib.sha256(S.read_bytes()).hexdigest();(D/'INPUT_GEOMETRY.json').write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')));(D/'INPUT_GEOMETRY.json.gz').write_bytes(gzip.compress((D/'INPUT_GEOMETRY.json').read_bytes(),mtime=0))
for keys,name in [(newids,'WANFO_REAR7_R01_ONLY.glb'),(list(ms),'WANFO_REAR7_R01_FULL89.glb')]:
 scene=trimesh.Scene()
 for k in keys:
  m=ms[k].copy();v=m.vertices.copy();m.vertices=np.c_[v[:,0],v[:,2],-v[:,1]]/1000;m.visual.face_colors=[188,116,46,255] if k in newids else [140,145,144,255];scene.add_geometry(m,node_name=k,geom_name=k)
 p=D/name;p.write_bytes(scene.export(file_type='glb'));back=trimesh.load(p,force='scene');assert set(back.geometry)==set(keys);err=0.
 for k in keys:
  v=back.geometry[k].vertices;v=np.c_[v[:,0],-v[:,2],v[:,1]]*1000;err=max(err,float(np.max(abs(v-ms[k].vertices))))
 assert err<.001;(D/(name+'.REOPEN.json')).write_text(json.dumps({'entities':len(keys),'max_coordinate_error_mm':err,'pass':True},indent=2))
print('REAR7_READY',flush=True)
