import json, shutil, hashlib, zipfile
from pathlib import Path
import numpy as np
import trimesh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib.collections import PolyCollection

p=Path('/workspace/scratch/c8225efbedd1/rear7_candidate_r01')
d=json.loads((p/'INPUT_GEOMETRY.json').read_text())
r=json.loads((p/'REAR7_R01_VALIDATION.json').read_text())
ids=r['new_pending_ids']
names=['柱','栌斗','第一跳华栱（局部）','交互斗','第二跳华栱（局部）','头昂（局部）','二昂（局部）']
font=FontProperties(fname='/workspace/scratch/c8225efbedd1/tmp/NotoSansCJKsc-Regular.otf')
plt.rcParams['font.family']=font.get_name()
from matplotlib import font_manager
font_manager.fontManager.addfont(font.get_file())
fig,ax=plt.subplots(figsize=(12,9))
colors=['#9c8065','#dea455','#569bb1','#c67a48','#6aaa87','#ab779a','#657dc1']
for i,oid in enumerate(ids+['trial:EAST_UPPER6_FULL_BEAM_CANDIDATE']):
 o=next(o for o in d['objects'] if o['id']==oid)
 mesh=trimesh.Trimesh(vertices=o['vertices'],faces=o['faces'],process=False)
 sec=mesh.section(plane_origin=[4437,0,0],plane_normal=[1,0,0])
 if sec:
  for v in sec.discrete:
   ax.fill(v[:,1]+5355,v[:,2],color=colors[i] if i<7 else '#dddddd',edgecolor='#333333',lw=.8,alpha=.85)
 if i<7:
  v=np.array(o['vertices']);x=(v[:,1].min()+v[:,1].max())/2+5355;z=(v[:,2].min()+v[:,2].max())/2
  if i==0:z=-2900
  ax.annotate(f'{i+1}  {names[i]}',xy=(x,z),xytext=(650,-2890+i*260),fontproperties=font,fontsize=11,arrowprops=dict(arrowstyle='-',color=colors[i]),bbox=dict(fc='white',ec=colors[i],pad=4))
ax.text(400,-920,'已有上六椽栿',fontproperties=font,color='#555555',fontsize=11)
ax.set_xlim(-1700,1500);ax.set_ylim(-3070,-690);ax.set_aspect('equal')
ax.set_xlabel('距假定后柱中心的纵向距离（mm；左为外端）',fontproperties=font)
ax.set_ylabel('模型高度坐标（mm）',fontproperties=font)
ax.grid(alpha=.15)
ax.set_title('后端七件候选 R01｜全部待审核\n实际网格中剖面；柱身下部仅在此图裁切',fontproperties=font,fontsize=17,pad=16)
fig.text(.06,.04,'形体起点：前端局部网格镜像；后端个体轮廓、槽深与层高仍是假设。\n接触／干涉检查通过，不等于历史形态或结构强度获证实。',fontproperties=font,fontsize=11)
fig.subplots_adjust(bottom=.16,top=.88)
fig.savefig(p/'WANFO_REAR7_R01_REVIEW_ZH.png',dpi=160)

rows='\n'.join(f'| {i+1} | {name} | {oid} | 待审核 |' for i,(name,oid) in enumerate(zip(names,ids)))
review=f'''# 后端七件候选 R01：待审核

按“资料核对 → 七件候选 → 最小接触链 → 整组检查 → 人工审核”的顺序完成本轮工作。七件仅获制作和试验授权，均未获外形批准。前端批准不转用于后端。

## 对象清单

| 图中编号 | 构件 | 对象 ID | 状态 |
|---|---|---|---|
{rows}

## 依据与假设

A1 PDF 49—65页支持构件类型、截面族及斗类统计尺寸；72—73页提供交接关系；81页描述上六椽栿承于二昂；292页提供东缝点云与推算关系；336页的北东头左右个体截面显示个体差异。PDF页码均为文件页序号。

尚未完成后端实物个体与模型对象的唯一绑定，不能把族平均值认定为后端单件实测值。逐件依据与缺口见 SOURCE_GATE.json。

本轮直接沿用前端七件局部网格作为设计起点并沿 Y=0 镜像；后柱中心 Y=-5355 来自已有上梁端点。相同层高、轮廓、槽形和昂斜率均属于候选假设。柱径约460mm为既有 Master 参考，柱高3534.3mm是可替换设计补足。此轮没有从后端点云重新拟合七件轮廓。

## 核验结果

- 最小试验：七件新增候选加已有上梁，共8件；28对干涉检查、7处连续向下接触检查通过。
- 整组：89件、3916对干涉检查通过，最大交叠体积 {r['max_overlap_mm3']:.9f} mm³，阈值1 mm³。
- 原43处接触全部保留，新增7处接触通过；原有82件几何完全一致。
- 实体封闭、体积为正、各自单连通检查通过；两个GLB独立重读误差小于0.001mm。

接触面积通过只证明候选几何具备这些接触，不证明实际承载力。未验证完整后铺作、横向约束、基础支承、结构强度及后端真实历史形态。没有执行新的云端 BLEND 回读验证。

## 文件与下一步

WANFO_REAR7_R01_ONLY.glb 仅含新增七件，柱身完整；WANFO_REAR7_R01_FULL89.glb 含装配参照。图中灰色上梁是已有参照，不属于新增七件。

先逐件审核外形与假设，再根据具体批准范围登记或修改候选。此次未公开上传后端七件，没有合并 main。
'''
(p/'REVIEW_ZH.md').write_text(review)
shutil.copy('/workspace/scratch/c8225efbedd1/build_rear7_candidate_r01.py',p/'build_rear7_candidate_r01.py')
shutil.copy(__file__,p/'render_rear7_review.py')
manifest={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in p.iterdir() if f.is_file() and f.suffix!='.zip' and f.name!='MANIFEST_SHA256.json'}
(p/'MANIFEST_SHA256.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile(p/'WANFO_REAR7_R01_REVIEW_PACKAGE.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(p.iterdir()):
  if f.is_file() and f.suffix!='.zip':z.write(f,f.name)
print('review package ready')
